
CTransaksi::CTransaksi(const std::string& fileTransaksi, const std::string& fileAnggota, const std::string& fileBuku)
    : filenameTransaksi(fileTransaksi), filenameAnggota(fileAnggota), filenameBuku(fileBuku) {
    bacaDariFileAnggota();
    bacaDariFileBuku();
    bacaDariFileTransaksi();
}