#include <iostream>
#include <conio.h>
#include "Modul.h"
#include "buku.cpp"
#include "anggota.cpp"
#include "transaksi.cpp"
using namespace std;
int main() {
    int pil; 
    string namaFilebuku = "perpus.txt";
    CBuku db(namaFilebuku);
    string namaFileanggota = "anggota.txt";
    CAnggota dbanggota(namaFileanggota);
    string namaFiletransaksi = "detail.txt";
    CTransaksi dbtrans(namaFiletransaksi,namaFileanggota,namaFilebuku);
    do
    {
        cout <<"---Aplikasi Management Perpustakaan---\n";
        cout <<"Menu Awal: \n";
        cout << "1. Manage Buku \n";
        cout << "2. Manage Anggota \n";
        cout << "3. Peminjaman Buku \n";
        cout << "4. Pengembalian Buku \n";
        cout << "5. Keluar \n";
        cout <<"Pilih Menu : ";
        cin >> pil;
        system("CLS");

        switch (pil)
        {
        case 1:
            db.menuBuku();
            break;
            getch();
            system("CLS");
        case 2:
            dbanggota.menuAnggota();
            break;
        case 3:
            dbtrans.trpeminjaman();
            break;
            getch();
            system("CLS");
        case 4:
            dbtrans.trpengembalian();
            break;
            getch();
            system("CLS");
        case 5:
            cout << "Keluar \n";
            break;    
        default:
            cout << "Pilihan tidak valid.\n";
        }
    } while (pil != 5);
    
    return 0;
}