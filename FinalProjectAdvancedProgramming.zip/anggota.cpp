#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm> 
#include <limits>
#include <conio.h>
#include "Modul.h"

using namespace std;

CAnggota::CAnggota(const std::string& filename) : namaFile(filename) {
    bacaDariFileAnggota();
}

void CAnggota::tambahAnggota() {
    Anggota anggota;

    bool isUniqueID;
    do {
        cout << "Masukkan ID anggota: ";
        cin >> anggota.id;

        auto it = find_if(anggotaDatabase.begin(), anggotaDatabase.end(),
                          [id = anggota.id](const Anggota &a) { return a.id == id; });

        isUniqueID = (it == anggotaDatabase.end());
        if (!isUniqueID) {
            cout << "ID sudah digunakan. Masukkan ID yang berbeda.\n";
        }

    } while (!isUniqueID);

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "Masukkan nama anggota: ";
    getline(cin, anggota.nama);

    anggotaDatabase.push_back(anggota);

    cout << "Anggota berhasil ditambahkan.\n";
    simpanKeFileAnggota();
}

void CAnggota::tampilkanAnggota() {
    if (anggotaDatabase.empty()) {
        cout << "Database Anggota kosong.\n";
    } else {
        cout << "Daftar Anggota:\n";
        for (const Anggota &anggota : anggotaDatabase) {
            cout << "ID: " << anggota.id << " | Nama: " << anggota.nama << "\n";
        }
    }
}

void CAnggota::ubahAnggota() {
    if (anggotaDatabase.empty()) {
        cout << "Database Anggota kosong. Tidak ada yang bisa diubah.\n";
        return;
    }

    cout << "Masukkan ID Anggota yang ingin diubah: ";
    int idAnggota;
    cin >> idAnggota;

    auto it = find_if(anggotaDatabase.begin(), anggotaDatabase.end(),
                      [idAnggota](const Anggota &a) { return a.id == idAnggota; });

    if (it != anggotaDatabase.end()) {
        cout << "Pilih bagian yang ingin diubah (id/nama): ";
        string bagian;
        cin >> bagian;

        if (bagian == "id") {
            cout << "Masukkan ID baru: ";
            cin >> it->id;
        } else if (bagian == "nama") {
            cout << "Masukkan nama baru: ";
            cin.ignore();
            getline(cin, it->nama);
        } else {
            cout << "Bagian tidak valid.\n";
        }

        cout << "Anggota berhasil diubah.\n";
        simpanKeFileAnggota();
    } else {
        cout << "Anggota dengan ID tersebut tidak ditemukan.\n";
    }
}

void CAnggota::hapusAnggota() {
    if (anggotaDatabase.empty()) {
        cout << "Database Anggota kosong. Tidak ada yang bisa dihapus.\n";
        return;
    }

    cout << "Masukkan ID Anggota yang ingin dihapus: ";
    int idAnggota;
    cin >> idAnggota;

    auto it = find_if(anggotaDatabase.begin(), anggotaDatabase.end(),
                      [idAnggota](const Anggota &a) { return a.id == idAnggota; });

    if (it != anggotaDatabase.end()) {
        anggotaDatabase.erase(it);
        cout << "Anggota berhasil dihapus.\n";
        simpanKeFileAnggota();
    } else {
        cout << "Anggota dengan ID tersebut tidak ditemukan.\n";
    }
}

void CAnggota::simpanKeFileAnggota() {
    ofstream file(namaFile);
    if (file.is_open()) {
        for (const auto &anggota : anggotaDatabase) {
            file << anggota.id << ',' << anggota.nama << '\n';
        }
        file.close();
    } else {
        cout << "Gagal membuka file untuk penyimpanan.\n";
    }
}

void CAnggota::bacaDariFileAnggota() {
    ifstream file(namaFile);
    if (file.is_open()) {
        anggotaDatabase.clear(); 

        Anggota anggota;
        char comma; 

        while (file >> anggota.id >> comma) {
            getline(file, anggota.nama);

            anggotaDatabase.push_back(anggota);
        }

        file.close();

        file.close();
    } else {
        cout << "Gagal membuka file untuk membaca data.\n";
    }
}

void CAnggota::menuAnggota() {
    int pilihan;
    do {
        cout << "Menu :\n";
        cout << "1. Tambah Anggota\n";
        cout << "2. Tampilkan Anggota\n";
        cout << "3. Ubah Anggota\n";
        cout << "4. Hapus Anggota\n";
        cout << "5. Kembali\n";
        cout << "Pilih menu (1-5): ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                tambahAnggota();
                getch();
                system("CLS");
                break;
            case 2:
                tampilkanAnggota();
                getch();
                system("CLS");
                break;
            case 3:
                ubahAnggota();
                getch();
                system("CLS");
                break;
            case 4:
                hapusAnggota();
                getch();
                system("CLS");
                break;
            case 5:
                cout << "Kembali.\n";
                system("CLS");
                break;
            default:
                cout << "Pilihan tidak valid. Masukkan pilihan 1-5.\n";
                break;
        }

    } while (pilihan != 5);
}
