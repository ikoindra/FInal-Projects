#ifndef MODUL_H
#define MODUL_H
#include <string>
#include <vector>


// struct
struct Buku{
    int id;
    std::string nama;
    int jumlah;
};

struct Anggota{
    int id;
    std::string nama;
};
struct Transaksi {
    int nofaktur;
    int anggota;
    std::string buku;
    int jumlah;
};

class CBuku {
private:
    std::vector<Buku> bukuDatabase;
    std::string namaFile;

    void mergeSort(std::vector<Buku>& arr, int left, int right, const std::string& sortBy);
    void merge(std::vector<Buku>& arr, int left, int middle, int right, const std::string& sortBy);

    void simpanKeFileBuku();
    void bacaDariFileBuku();

public:
    CBuku(const std::string& filename);
    void tambahBuku();
    void tampilkanBuku();
    void ubahBuku();
    void hapusBuku();
    void menuBuku();
};

class CAnggota
{
private:
    std::vector<Anggota> anggotaDatabase;
    std::string namaFile;
public:
    CAnggota(const std::string& filename);
    void tambahAnggota(); 
    void tampilkanAnggota();
    void ubahAnggota(); 
    void hapusAnggota(); 
    void simpanKeFileAnggota();
    void bacaDariFileAnggota();
    void menuAnggota();
};

class CTransaksi {
private:
    std::vector<Transaksi> transaksiDatabase;
    std::vector<Anggota> anggotaDatabase;
    std::vector<Buku> bukuDatabase;
    std::string filenameTransaksi;
    std::string filenameAnggota;
    std::string filenameBuku;

    void simpanKeFileTransaksi();
    void simpanKeFileDetail();
    void simpanKeFileBuku();
    void bacaDariFileAnggota();
    void bacaDariFileBuku();
    void bacaDariFileTransaksi();
public:
    CTransaksi(const std::string& fileTransaksi, const std::string& fileAnggota, const std::string& fileBuku);

    void trpeminjaman();
    void trpengembalian();
    static void merge(std::vector<Buku>& arr, int left, int middle, int right);
    static void mergeSort(std::vector<Buku>& arr, int left, int right);
    void urutkanBuku(std::vector<Buku>& bukuDatabase);
    int binarySearch(const std::vector<Buku>& arr, const std::string& key);
};

#endif
