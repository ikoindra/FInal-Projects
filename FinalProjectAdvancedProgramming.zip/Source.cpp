#include <iostream>
#include <string>
#include <conio.h>

using namespace std;

// Definisi Struktur Buku
struct Book {
    int id;
    string title;
    string author;
    string category;
    int year;
    bool isBorrowed;
    string borrowerName; // New field for borrower's name
    string borrowerNPM;  // New field for borrower's npm
    Book* next;
};

// Definisi Node untuk Single Linked List
struct Node {
    Book data;
    Node* next;
};

// Definisi Node untuk Binary Search Tree
struct TreeNode {
    Book data;
    TreeNode* left;
    TreeNode* right;
};

// Definisi Node untuk Binary Search Tree Kategori
struct CategoryNode {
    string category;
    Node* bookListHead;
    CategoryNode* left;
    CategoryNode* right;
};

// Definisi Struktur Queue untuk Peminjaman Buku
struct QueueNode {
    int bookID;
    string bookTitle;
    string borrowerName;
    string borrowerNPM;
    bool isBorrowing; // true for borrowing, false for returning
    QueueNode* next;
};

// Variabel global untuk head dan tail dari queue
QueueNode* queueFront = nullptr;
QueueNode* queueRear = nullptr;


Node* head = nullptr;
TreeNode* root = nullptr;
CategoryNode* categoryRoot = nullptr;

// Fungsi untuk Menambah Buku ke Linked List
void addBookToList(const Book& newBook) {
    Node* newNode = new Node;
    newNode->data = newBook;
    newNode->next = head;
    head = newNode;
}

// Fungsi untuk Menambah Buku ke Binary Search Tree berdasarkan tahun terbit
void addBookToTree(const Book& newBook, TreeNode*& node) {
    if (node == nullptr) {
        node = new TreeNode;
        node->data = newBook;
        node->left = nullptr;
        node->right = nullptr;
    }
    else if (newBook.year < node->data.year) {
        addBookToTree(newBook, node->left);
    }
    else {
        addBookToTree(newBook, node->right);
    }
}

// Fungsi untuk Menambah Buku ke Binary Search Tree Kategori
void addBookToCategoryTree(const Book& newBook, CategoryNode*& node) {
    if (node == nullptr) {
        node = new CategoryNode;
        node->category = newBook.category;
        node->bookListHead = nullptr;
        node->left = nullptr;
        node->right = nullptr;
    }

    // Jika kategori sudah ada, tambahkan buku ke dalam linked list kategori tersebut
    if (newBook.category == node->category) {
        Node* newNode = new Node;
        newNode->data = newBook;
        newNode->next = node->bookListHead;
        node->bookListHead = newNode;
    }
    else if (newBook.category < node->category) {
        addBookToCategoryTree(newBook, node->left);
    }
    else {
        addBookToCategoryTree(newBook, node->right);
    }
}

// Fungsi untuk Mencari Buku Berdasarkan Kategori
void searchBookByCategory(CategoryNode* node, const string& category, bool& found) {
    if (node != nullptr && !found) {
        if (category == node->category) {
            cout << "Buku dalam kategori '" << category << "':" << endl;
            Node* current = node->bookListHead;
            while (current != nullptr) {
                cout << "ID: " << current->data.id << ", Judul: " << current->data.title
                    << ", Pengarang: " << current->data.author << ", Tahun Terbit: " << current->data.year << endl;
                current = current->next;
            }
            cout << "---------------------------" << endl;
            found = true;
            return;  // Keluar dari fungsi setelah menemukan buku
        }
        searchBookByCategory(node->left, category, found);
        searchBookByCategory(node->right, category, found);
    }
}


// Fungsi untuk Mencari Buku Berdasarkan Tahun Terbit
void searchBookByYear(TreeNode* node, int year, bool& found) {
    if (node != nullptr) {
        if (year == node->data.year) {
            cout << "ID: " << node->data.id << ", Judul: " << node->data.title
                << ", Pengarang: " << node->data.author << ", Kategori: " << node->data.category << ", Tahun Terbit: " << node->data.year << endl;
            found = true;
            // Tidak menggunakan return di sini agar pencarian bisa melanjutkan ke buku lainnya
        }
        searchBookByYear(node->left, year, found);
        searchBookByYear(node->right, year, found);
    }
}

// Fungsi untuk Mencari Buku Berdasarkan Judul
void searchBookByTitle() {
    string title;
    cout << "Masukkan judul buku yang dicari: ";
    cin.ignore();
    getline(cin, title);

    Node* current = head;
    bool found = false;

    while (current != nullptr) {
        if (current->data.title == title) {
            found = true;
            cout << "ID: " << current->data.id << ", Judul: " << current->data.title
                << ", Pengarang: " << current->data.author << ", Kategori: " << current->data.category << ", Tahun Terbit: " << current->data.year << endl;
        }
        current = current->next;
    }

    if (!found) {
        cout << "Buku dengan judul '" << title << "' tidak ditemukan." << endl;
    }
}

// Fungsi untuk Menampilkan Semua Buku dalam Daftar
void displayBookList() {
    cout << "======== Daftar Buku ========" << endl;
    Node* current = head;
    while (current != nullptr) {
        cout << "ID: " << current->data.id << ", Judul: " << current->data.title
            << ", Pengarang: " << current->data.author << ", Kategori: " << current->data.category << ", Tahun Terbit: " << current->data.year << endl;
        current = current->next;
    }
    cout << "=============================" << endl;
}

// Fungsi untuk Menampilkan Daftar Peminjaman dari Queue
void displayQueue() {
    cout << "======== Daftar Antrian Peminjaman ========" << endl;

    QueueNode* current = queueFront;
    while (current != nullptr) {
        cout << "ID Buku: " << current->bookID << ", Nama Peminjam: " << current->borrowerName
            << ", NPM Peminjam: " << current->borrowerNPM << ", Status: ";
        if (current->isBorrowing) {
            cout << "Mengantri untuk meminjam";
        }
        else {
            cout << "Mengantri untuk mengembalikan";
        }
        cout << endl;

        current = current->next;
    }

    cout << "=========================================" << endl;
}

// Fungsi untuk Menambah Peminjaman ke Queue
void enqueueBorrow() {
    string searchTitle;
    cout << "Cari judul buku yang ingin dipinjam: ";
    cin.ignore();
    getline(cin, searchTitle);

    Node* current = head;
    bool found = false;

    while (current != nullptr) {
        if (current->data.title == searchTitle && !current->data.isBorrowed) {
            found = true;
            // Update book information
            current->data.isBorrowed = true;

            // Borrower information
            cout << "Nama peminjam: ";
            cin.ignore();
            getline(cin, current->data.borrowerName);

            cout << "NPM peminjam: ";
            getline(cin, current->data.borrowerNPM);
            break;
        }
        current = current->next;
    }

    if (!found) {
        cout << "Buku berjudul \"" << searchTitle << "\" sedang dipinjam." << endl;
        // Ask if the user wants to be in the queue
        char queueChoice;
        cout << "Apakah ingin masuk antrian peminjam? (y/n): ";
        cin >> queueChoice;
        if (queueChoice == 'y' || queueChoice == 'Y') {
            string borrowerName, borrowerNPM;
            cout << "Masukkan Nama Peminjam: ";
            cin.ignore();
            getline(cin, borrowerName);

            cout << "Masukkan NPM Peminjam: ";
            getline(cin, borrowerNPM);

            // Tambahkan peminjaman ke dalam queue
            QueueNode* newNode = new QueueNode;
            newNode->bookTitle = searchTitle;
            newNode->borrowerName = borrowerName;
            newNode->borrowerNPM = borrowerNPM;
            newNode->isBorrowing = true;
            newNode->next = nullptr;

            if (queueFront == nullptr) {
                queueFront = newNode;
                queueRear = newNode;
            } else {
                queueRear->next = newNode;
                queueRear = newNode;
            }

            cout << "Anda telah masuk ke dalam antrian." << endl;
            displayQueue();
        }
    }
    else {
        cout << "Berhasil meminjam buku" << endl;
    }
}

void enqueueReturn() {
    int bookID;
    cout << "Masukkan ID Buku yang akan dikembalikan: ";
    cin >> bookID;

    Node* current = head;
    bool found = false;

    while (current != nullptr) {
        if (current->data.id == bookID && current->data.isBorrowed) {
            found = true;
            // Update informasi buku
            current->data.isBorrowed = false;
            current->data.borrowerName = "";
            current->data.borrowerNPM = "";

            // Jika ada yang menunggu di antrian, pinjamkan ke orang pertama di antrian
            if (queueFront != nullptr) {
                // Ambil informasi peminjam dari antrian
                QueueNode* borrowedNode = queueFront;
                // Update informasi buku
                current->data.isBorrowed = true;
                current->data.borrowerName = borrowedNode->borrowerName;
                current->data.borrowerNPM = borrowedNode->borrowerNPM;
                // Hapus dari antrian
                queueFront = queueFront->next;
                delete borrowedNode;

                cout << "Buku berhasil dikembalikan dan dipinjamkan ke " << current->data.borrowerName << " (NPM: " << current->data.borrowerNPM << ")." << endl;
            }
            else {
                cout << "Buku berhasil dikembalikan dan kembali tersedia." << endl;
            }
            break;
        }
        current = current->next;
    }

    if (!found) {
        cout << "Buku tidak valid untuk dikembalikan." << endl;
    }
}

void displayBorrowedBooks() {
    cout << "======== Daftar Buku Dipinjam ========" << endl;

    Node* current = head;
    while (current != nullptr) {
        if (current->data.isBorrowed) {
            cout << "ID: " << current->data.id << ", Judul: " << current->data.title
                << ", Pengarang: " << current->data.author << ", Kategori: " << current->data.category
                << ", Tahun Terbit: " << current->data.year << ", Status Peminjaman: Dipinjam oleh "
                << current->data.borrowerName << " (NPM: " << current->data.borrowerNPM << ")" << endl;
        }
        current = current->next;
    }

    cout << "=====================================" << endl;
}

// Fungsi untuk Hapus Buku
void deleteBook() {
    int bookID;
    cout << "Masukkan ID Buku yang akan dihapus: ";
    cin >> bookID;

    Node* current = head;
    Node* prev = nullptr;
    bool found = false;

    while (current != nullptr) {
        if (current->data.id == bookID) {
            found = true;
            // Jika buku yang dihapus berada di awal linked list
            if (prev == nullptr) {
                head = current->next;
            }
            else {
                prev->next = current->next;
            }

            delete current;
            cout << "Buku dengan ID " << bookID << " berhasil dihapus." << endl;
            break;
        }
        prev = current;
        current = current->next;
    }

    if (!found) {
        cout << "Buku dengan ID " << bookID << " tidak ditemukan." << endl;
    }
}

// Fungsi untuk Menambah Buku
void addBook() {
    Book newBook;
    cout << "Masukkan ID Buku: ";
    cin >> newBook.id;
    cout << "Masukkan Judul Buku: ";
    cin.ignore();
    getline(cin, newBook.title);
    cout << "Masukkan Pengarang Buku: ";
    getline(cin, newBook.author);
    cout << "Masukkan Kategori Buku: ";
    getline(cin, newBook.category);
    cout << "Masukkan Tahun Terbit Buku: ";
    cin >> newBook.year;
    newBook.isBorrowed = false;

    // Tambahkan buku ke Linked List
    addBookToList(newBook);

    // Tambahkan buku ke Binary Search Tree
    addBookToTree(newBook, root);

    // Tambahkan buku ke Binary Search Tree Kategori
    addBookToCategoryTree(newBook, categoryRoot);

    cout << "Buku berhasil ditambahkan!" << endl;
}

// Fungsi untuk Menampilkan Halaman Pencarian
void halamanCari() {
    int pilihan;
    bool foundYear = false;
    bool foundCategory = false;

    cout << "======== Halaman Cari ========\n";
    cout << "1. Cari berdasarkan Judul\n";
    cout << "2. Cari berdasarkan Tahun Terbit\n";
    cout << "3. Cari berdasarkan Kategori\n";
    cout << "============================\n";

    cout << "Masukkan pilihan Anda: ";
    cin >> pilihan;

    switch (pilihan) {
    case 1:
        searchBookByTitle();
        break;
    case 2:
        int searchYear;
        cout << "Masukkan tahun terbit buku yang dicari: ";
        cin >> searchYear;
        searchBookByYear(root, searchYear, foundYear);
        if (!foundYear) {
            cout << "Data tidak ditemukan" << endl;
        }
        break;
    case 3:
        string searchCategory;
        cout << "Masukkan kategori buku yang dicari: ";
        cin.ignore();
        getline(cin, searchCategory);
        searchBookByCategory(categoryRoot, searchCategory, foundCategory);
        if (!foundCategory) {
            cout << "Data tidak ditemukan" << endl;
        }
        break;
    }
}

void daftarpeminjamanbuku() {
    cout << "======== Daftar Buku Dipinjam ========" << endl;

    Node* current = head;
    while (current != nullptr) {
        if (current->data.isBorrowed) {
            cout << "ID: " << current->data.id << ", Judul: " << current->data.title
                << ", Pengarang: " << current->data.author << ", Kategori: " << current->data.category
                << ", Tahun Terbit: " << current->data.year << ", Status Peminjaman: Dipinjam" << endl;
        }
        current = current->next;
    }

    cout << "=====================================" << endl;
}

int main() {

    Book book1 = {1, "The Catcher in the Rye", "J.D. Salinger", "Fiction", 1951, false, "", "", nullptr};
    Book book2 = {2, "To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, false, "", "", nullptr};
    Book book3 = {3, "1984", "George Orwell", "Science Fiction", 1949, false, "", "", nullptr};

    // Add books to the linked list, binary search tree, and category binary search tree
    addBookToList(book1);
    addBookToList(book2);
    addBookToList(book3);

    addBookToTree(book1, root);
    addBookToTree(book2, root);
    addBookToTree(book3, root);

    addBookToCategoryTree(book1, categoryRoot);
    addBookToCategoryTree(book2, categoryRoot);
    addBookToCategoryTree(book3, categoryRoot);

    int choice;

    do {
        cout << "======== Menu Utama ========" << endl;
        cout << "1. Tambah Buku" << endl;
        cout << "2. Hapus Buku" << endl;
        cout << "3. Cari Buku" << endl;
        cout << "4. Pinjam Buku" << endl;
        cout << "5. Kembalikan Buku" << endl;
        cout << "6. Lihat Daftar Buku" << endl;
        cout << "7. Lihat Daftar Peminjaman" << endl;
        cout << "8. Keluar" << endl;
        cout << "============================" << endl;

        cout << "Masukkan pilihan Anda: ";
        cin >> choice;
        system("cls");

        switch (choice) {
        case 1:
            addBook();
            getch();
            system("CLS");
            break;
        case 2:
            deleteBook();
            getch();
            system("CLS");
            break;
        case 3:
            halamanCari();
            getch();
            system("CLS");
            break;
        case 4:
            enqueueBorrow();
            getch();
            system("CLS");
            // Implementasi fungsi pinjam buku
            break;
        case 5:
            enqueueReturn();
            getch();
            system("CLS");
            // updateBookInfo();
            break;
        case 6:
            displayBookList();
            getch();
            system("CLS");
            break;
        case 7:
            daftarpeminjamanbuku();
            getch();
            system("CLS");
            break;
        case 8:
            cout << "Terima kasih! Keluar dari program." << endl;
            break;
        default:
            cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
        }

    } while (choice != 8);

    // Hapus semua node di akhir program
    Node* current = head;
    while (current != nullptr) {
        Node* temp = current;
        current = current->next;
        delete temp;
    }

    return 0;
}