#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "Modul.h"

std::vector<Anggota> anggotaDatabase;
std::vector<Buku> bukuDatabase;
std::vector<Transaksi> transaksiDatabase;
std::string filenameAnggota;
std::string filenameBuku;
std::string filenameTransaksi;

using namespace std;

void CTransaksi::bacaDariFileBuku() {
    ifstream file(filenameBuku);
    if (file.is_open()) {
        bukuDatabase.clear();
        Buku buku;
        while (file >> buku.id) {
            file.ignore();
            getline(file, buku.nama, ',');
            file >> buku.jumlah;
            bukuDatabase.push_back(buku);
        }

        file.close();
    } else {
        cout << "Gagal membuka file untuk membaca data buku.\n";
    }
}

void CTransaksi::bacaDariFileAnggota() {
    ifstream file(filenameAnggota);
    if (file.is_open()) {
        anggotaDatabase.clear(); 

        Anggota anggota;
        char comma; 

        while (file >> anggota.id >> comma) {
            getline(file, anggota.nama);
            anggotaDatabase.push_back(anggota);
        }

        file.close();
    } else {
        cout << "Gagal membuka file untuk membaca data anggota.\n";
    }
}

void CTransaksi::bacaDariFileTransaksi() {
    ifstream file(filenameTransaksi);
    if (file.is_open()) {
        transaksiDatabase.clear();
        Transaksi transaksi;
        char comma;

        while (file >> transaksi.nofaktur >> comma >> transaksi.anggota >> comma) {
            getline(file, transaksi.buku, ',');

            file >> transaksi.jumlah;

            if (file.fail()) {
                cout << "Gagal membuka file untuk membaca data transaksi.\n";
                break;
            }

            transaksiDatabase.push_back(transaksi);
        }

        file.close();
    } else {
        cout << "Gagal membuka file untuk membaca data transaksi.\n";
    }
}

void CTransaksi::mergeSort(std::vector<Buku>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        merge(arr, left, mid, right);
    }
}

void CTransaksi::merge(std::vector<Buku>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    std::vector<Buku> leftArr(n1);
    std::vector<Buku> rightArr(n2);

    for (int i = 0; i < n1; i++) {
        leftArr[i] = arr[left + i];
    }
    for (int j = 0; j < n2; j++) {
        rightArr[j] = arr[mid + 1 + j];
    }

    int i = 0; 
    int j = 0; 
    int k = left; 

    while (i < n1 && j < n2) {
        if (leftArr[i].nama < rightArr[j].nama) {
            arr[k++] = leftArr[i++];
        } else {
            arr[k++] = rightArr[j++];
        }
    }

    while (i < n1) {
        arr[k++] = leftArr[i++];
    }

    while (j < n2) {
        arr[k++] = rightArr[j++];
    }
}

void CTransaksi::urutkanBuku(std::vector<Buku>& bukuDatabase) {
    for (auto& buku : bukuDatabase) {
        transform(buku.nama.begin(), buku.nama.end(), buku.nama.begin(), ::tolower);
    }

    mergeSort(bukuDatabase, 0, bukuDatabase.size() - 1);
}

int CTransaksi::binarySearch(const std::vector<Buku>& arr, const std::string& key) {
    int low = 0;
    int high = arr.size() - 1;

    std::string lowercaseKey = key;
    transform(lowercaseKey.begin(), lowercaseKey.end(), lowercaseKey.begin(), ::tolower);

    while (low <= high) {
        int mid = low + (high - low) / 2;
        std::string midName = arr[mid].nama;

        transform(midName.begin(), midName.end(), midName.begin(), ::tolower);

        if (lowercaseKey == midName) {
            return mid; 
        } else if (lowercaseKey < midName) {
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }

    return -1; 
}

CTransaksi::CTransaksi(const std::string& fileTransaksi, const std::string& fileAnggota, const std::string& fileBuku)
    : filenameTransaksi(fileTransaksi), filenameAnggota(fileAnggota), filenameBuku(fileBuku) {
    bacaDariFileAnggota();
    bacaDariFileBuku();
    bacaDariFileTransaksi();
}

void CTransaksi::trpeminjaman() {
    urutkanBuku(bukuDatabase);
    cin.ignore();
    Transaksi transaksi;

    cout << "Masukkan no. peminjaman: ";
    cin >> transaksi.nofaktur;

    cout << "Masukkan ID anggota: ";
    cin >> transaksi.anggota;

    bool anggotaExists = false;
    for (const Anggota& anggota : anggotaDatabase) {
        if (transaksi.anggota == anggota.id) {
            anggotaExists = true;
            break;
        }
    }

    if (!anggotaExists) {
        cout << "Anggota dengan ID tersebut tidak ditemukan.\n";
        getch();
        return;
    }

    cin.ignore();

    int pilihan;

    do {
        cout << "Cari judul buku: ";
        getline(cin, transaksi.buku);

        transform(transaksi.buku.begin(), transaksi.buku.end(), transaksi.buku.begin(), ::tolower);

        int index = binarySearch(bukuDatabase, transaksi.buku);

        if (index != -1) {
            cout << "Buku ditemukan:\n";
            Buku& buku = bukuDatabase[index];
            cout << "ID: " << buku.id << " | Nama: " << buku.nama << " | Jumlah: " << buku.jumlah << "\n";

            cout << "Masukkan jumlah buku yang ingin dipinjam: ";
            int borrowedQuantity;
            while (!(cin >> borrowedQuantity) || borrowedQuantity <= 0 || borrowedQuantity > buku.jumlah) {
                cout << "Input invalid. Masukkan jumlah buku yang ingin dipinjam (angka positif dan tidak melebihi stok): ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }

            buku.jumlah -= borrowedQuantity;

            transaksi.jumlah = borrowedQuantity; 
            transaksiDatabase.push_back(transaksi);
            simpanKeFileTransaksi();
            simpanKeFileBuku();

            cout << "Apakah ingin meminjam lagi? (1. Ya / 2. Tidak) ";
            while (!(cin >> pilihan) || (pilihan != 1 && pilihan != 2)) {
                cout << "Input invalid. Masukkan 1 untuk Ya atau 2 untuk Tidak: ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }

            cin.ignore();
        } else {
            cout << "Buku tidak ditemukan.\n";
        }
    } while (pilihan == 1);
    system("CLS");
}

void CTransaksi::trpengembalian() {

    cout << "============Daftar Peminjaman==============\n";
    if (transaksiDatabase.empty()) {
        cout << "Database peminjaman kosong.\n";
    }
    for (const auto& t : transaksiDatabase) {
        cout << "No. Faktur: " << t.nofaktur << ", Anggota: " << t.anggota << ", Buku: " << t.buku << ", Jumlah: " << t.jumlah << endl;
    }

    int noFaktur;

    cout << "Masukkan nomor peminjaman (nofaktur): ";
    cin >> noFaktur;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    auto itTransaksi = find_if(transaksiDatabase.begin(), transaksiDatabase.end(),
                               [noFaktur](const Transaksi& t) { return t.nofaktur == noFaktur; });

    if (itTransaksi != transaksiDatabase.end()) {
        std::string namaBuku = itTransaksi->buku;
        int jumlahDipinjam = itTransaksi->jumlah;

        auto itBuku = find_if(bukuDatabase.begin(), bukuDatabase.end(),
                              [namaBuku](const Buku& b) { return b.nama == namaBuku; });

        if (itBuku != bukuDatabase.end()) {
            itBuku->jumlah += jumlahDipinjam;

            transaksiDatabase.erase(itTransaksi);

            simpanKeFileTransaksi();
            simpanKeFileBuku();

            cout << "Buku berhasil dikembalikan.\n";
        } else {
            cout << "Error: Buku tidak ditemukan dalam database buku.\n";
        }
    } else {
        cout << "Error: Nomor peminjaman tidak ditemukan dalam database transaksi.\n";
        getch();
        system("CLS");
    }
    getch();
    system("CLS");
}

void CTransaksi::simpanKeFileBuku() {
    ofstream file(filenameBuku);
    if (file.is_open()) {
        for (const Buku& buku : bukuDatabase) {
            file << buku.id << ',' << buku.nama << ',' << buku.jumlah << '\n';
        }
        file.close();
    } else {
        cout << "Gagal membuka file untuk penyimpanan.\n";
    }
}

void CTransaksi::simpanKeFileTransaksi() {
    ofstream file(filenameTransaksi, ios::trunc); 
    if (file.is_open()) {
        for (const Transaksi& transaksi : transaksiDatabase) {
            file << transaksi.nofaktur << ',' << transaksi.anggota << ',' << transaksi.buku << ',' << transaksi.jumlah << '\n';
        }
        file.close();
    } else {
        cout << "Gagal membuka file untuk penyimpanan.\n";
    }
}